<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperSheep extends SlapperEntity {

    const TYPE_ID = 13;
    const HEIGHT = 1.3;

}
