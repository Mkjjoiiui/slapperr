<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperBlaze extends SlapperEntity {

    const TYPE_ID = 43;
    const HEIGHT = 1.8;

}
