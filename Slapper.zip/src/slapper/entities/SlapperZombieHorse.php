<?php

declare(strict_types=1);

namespace slapper\entities;

class SlapperZombieHorse extends SlapperEntity {

    const TYPE_ID = 27;
    const HEIGHT = 1.6;

}
